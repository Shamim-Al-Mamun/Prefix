<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h4 class="page-title">Pricing</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.pricing.all')); ?>">Pricing lists</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.pricing.addnew')); ?>">Add New Pricing</a>
            </li>
        </ul>
    </div>

    <form action="<?php echo e(route('admin.pricing.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title">Add new package</h4>
                <button class="btn btn-success" type="submit" name="submit">Save Header</button>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6">

                        <div class="form-group">
                            <select class="form-control show-tick" name="pricing_category_id">
                                <option selected disabled>-- Please select--</option>
                                <?php $__currentLoopData = $pricing_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pricing_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pricing_cat->id); ?>"> <?php echo e($pricing_cat->pricing_category_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="pricing_title">Type Title</label>
                            <input type="text" class="form-control" id="pricing_title" name="pricing_title"
                                value="" placeholder="Type here">
                        </div>

                        

                        <div class="form-group">
                            <label for="pricing_price_amount">Type Amount</label>
                            <input type="number" class="form-control" id="pricing_price_amount" name="pricing_price_amount"
                                value="" placeholder="Type here">
                        </div>

                        

                        <div class="form-group">
                            <label for="pricing_price_desc">Pricing Lists</label>
                            <textarea type="text" class="form-control" id="pricing_price_desc" name="pricing_price_desc" placeholder="Type here"></textarea>
                        </div>

                        

                        <div class="form-group">
                            <label for="pricing_price_button_text">Button Text</label>
                            <input type="text" class="form-control" id="pricing_price_button_text"
                                name="pricing_price_button_text" value="" placeholder="Type here" maxlength="20">
                        </div>

                        

                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        ClassicEditor
            .create(document.querySelector('#pricing_price_desc'))
            .catch(error => {
                console.error(error);
            });
    </script>
    <script>
        ClassicEditor
            .create(document.querySelector('#pricing_price_amount_bottom'))
            .catch(error => {
                console.error(error);
            });
    </script>
    <script>
        ClassicEditor
            .create(document.querySelector('#pricing_price_offer_desc'))
            .catch(error => {
                console.error(error);
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web App\X speed\resources\views/pages/dashboard/pricing/addnew.blade.php ENDPATH**/ ?>