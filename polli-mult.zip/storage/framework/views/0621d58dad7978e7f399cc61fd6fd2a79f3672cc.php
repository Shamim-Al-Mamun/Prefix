<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h4 class="page-title">Blog setting</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.blog.category.all')); ?>">Blog Categories</a>
            </li>
        </ul>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="add-row" class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Thumbnail</th>
                                <th>Topic</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($blogCategory) > 0): ?>
                                <?php $__currentLoopData = $blogCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if(!empty($Category->icon)): ?>
                                                <span class="blog-card-badge offer-badge"><i
                                                        class="fa solid <?php echo e($Category->icon); ?>"></i>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(!empty($Category->topic)): ?>
                                                <?php echo e($Category->topic); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="button-group">
                                                <a href="<?php echo e(route('admin.blog.category.edit', $Category->id)); ?>"
                                                    class="btn btn-secondary">Edit</a>
                                                <form action="<?php echo e(route('admin.blog.category.destroy', $Category->id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <input type="submit" name="submit" value="Delete"
                                                        class="btn btn-danger">
                                                </form>
                                            </div>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>




                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web App\X speed\resources\views/pages/dashboard/blog/blog-cat/all.blade.php ENDPATH**/ ?>