<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h4 class="page-title">All Order Request</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('customer.order.all')); ?>">All Package Order Request</a>
            </li>
        </ul>
    </div>



    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="add-row" class="display table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Package</th>
                                <th>First name</th>
                                <th>Last name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Address</th>
                                
                                <th>Comment</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($order_request_all) > 0): ?>
                                <?php $__currentLoopData = $order_request_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($order->package_name); ?></td>
                                        <td><?php echo e($order->customer_first_name); ?></td>
                                        <td><?php echo e($order->customer_last_name); ?></td>
                                        <td><?php echo e($order->customer_number); ?></td>
                                        <td><?php echo e($order->customer_email); ?></td>
                                        <td><?php echo e($order->customer_address); ?></td>
                                        
                                        <td><?php echo e($order->customer_comments); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web App\X speed\resources\views/pages/dashboard/all-order-request.blade.php ENDPATH**/ ?>