    <!-- Blog Page Area -->
    <section class="blog-section-area">
        <div class="container">
            <div class="row">

                <?php if(count($blogs) > 0): ?>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="blog-card-single offer-card-single">
                                <div class="blog-card-single-img">
                                    <?php if(!empty($blog->img)): ?>
                                        <img src="<?php echo e(url($blog->img)); ?>" alt="#" />
                                    <?php endif; ?>
                                    <span class="blog-card-badge offer-badge"><i class="fa solid <?php echo e($blog->icon); ?>"></i>
                                        <?php echo e($blog->topic); ?></span>
                                </div>
                                <div class="blog-card-content">
                                    <h4 class="blog-card-cont-title">
                                        <?php echo e($blog->title); ?>

                                    </h4>
                                    <div class="blog-card-cont-btn">
                                        <a class="ISPTemplateV1-btn" href="<?php echo e(route('page.blog', $blog->id)); ?>">Read more<i
                                                class="fi fi-rr-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

            

        </div>
    </section>
    <!-- End Blog Page Area -->
<?php /**PATH D:\Web App\X speed\resources\views/pages/front/sections/Blogs/Blogs.blade.php ENDPATH**/ ?>