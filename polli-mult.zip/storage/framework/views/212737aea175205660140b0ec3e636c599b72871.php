    <!-- Breadcrumbs Area -->
    <section class="ISPTemplateV1-breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-xl-6 offset-xl-3 col-md-8 offset-md-2 col-12">
                    <div class="breadcrumbs-content">
                        <h4 class="breadcrumbs-cont-title"><?php echo e($contact_title->contact_section_label); ?></h4>
                        <p class="breadcrumbs-cont-text">
                            <?php echo e($contact_title->contact_section_title_middle); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Breadcrumbs Area -->
<?php /**PATH D:\Web App\ISP\Prefix\resources\views/pages/front/sections/Contact/Breadcrumbs.blade.php ENDPATH**/ ?>