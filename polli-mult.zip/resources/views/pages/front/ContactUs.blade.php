@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Contact.Breadcrumbs')
    @include('pages.front.sections.Contact.Form')
    @include('pages.front.sections.Contact.Info')
@endsection
