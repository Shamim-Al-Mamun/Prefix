@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Speed.Breadcrumbs')
    @include('pages.front.sections.Speed.Speed')
@endsection
