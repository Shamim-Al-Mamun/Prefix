@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Bill.Breadcrumbs')
    @include('pages.front.sections.Bill.Pay')
@endsection
