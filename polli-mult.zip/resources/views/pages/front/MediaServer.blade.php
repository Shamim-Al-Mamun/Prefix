@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Media.Breadcrumbs')
    @include('pages.front.sections.Media.Server')
@endsection
