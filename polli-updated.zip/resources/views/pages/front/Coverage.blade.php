@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Coverage.Breadcrumbs')
    @include('pages.front.sections.Coverage.Coverage')
@endsection
