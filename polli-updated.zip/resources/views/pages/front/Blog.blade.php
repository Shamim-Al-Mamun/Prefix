@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Blogs.Blog.Breadcrumbs')
    @include('pages.front.sections.Blogs.Blog.Blog')
@endsection
