@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Terms.Breadcrumbs')
    @include('pages.front.sections.Terms.Terms')
@endsection
