@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Policy.Breadcrumbs')
    @include('pages.front.sections.Policy.Policy')
@endsection
