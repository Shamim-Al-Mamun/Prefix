@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.AboutUs.Breadcrumbs')
    @include('pages.front.sections.Hero.About')
    @include('pages.front.sections.Hero.client')
    @include('pages.front.sections.Hero.WhatAreWe')
@endsection
