@extends('layouts.front.app')
@section('content')
    @include('pages.front.sections.Blogs.Breadcrumbs')
    @include('pages.front.sections.Blogs.Blogs')
@endsection
