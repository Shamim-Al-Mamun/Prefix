<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GoogleMaps extends Model
{
    protected $fillable = [
        'maps_iframe_code', 
    ];
   // use HasFactory;
}
