  <!-- Hero Area -->
  <section class="ISPTemplateV1-hero" style="background-image: url('./assets/img/hero-img/hero-bg.jpg')">
      <div class="container">
          <div class="row align-items-center">
              <div class="col-12">
                  <div class="hero-slider">

                      <?php if(count($heros) > 0): ?>
                          <?php $__currentLoopData = $heros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="hero-single-slider">
                                  <div class="row align-items-center">
                                      <div class="col-lg-6 col-12">
                                          <?php if(!empty($hero->hero_thumbnail)): ?>
                                              <div class="hero-img">
                                                  <img src="<?php echo e(url($hero->hero_thumbnail)); ?>" alt="#" />
                                              </div>
                                          <?php endif; ?>
                                      </div>
                                      <div class="col-lg-6 col-12">
                                          <div class="hero-content">
                                              
                                              <?php if(!empty($hero->hero_title)): ?>
                                                  <h1 class="hero-cont-big-title">
                                                      <?php echo e($hero->hero_title); ?>

                                                  </h1>
                                              <?php endif; ?>
                                              <?php if(!empty($hero->hero_text)): ?>
                                                  <p class="hero-cont-text">
                                                      <?php echo e($hero->hero_text); ?>

                                                  </p>
                                              <?php endif; ?>
                                              <div class="hero-content-btn">
                                                  <?php if(!empty($hero->hero_main_button)): ?>
                                                      <a href="<?php echo e($hero->hero_main_button_link); ?>"
                                                          class="ISPTemplateV1-btn">
                                                          <?php echo e($hero->hero_main_button); ?>

                                                      </a>
                                                  <?php endif; ?>
                                                  <?php if(!empty($hero->hero_main_button_two)): ?>
                                                      <a href="<?php echo e($hero->hero_main_button_two_link); ?>"
                                                          class="ISPTemplateV1-btn secondary">
                                                          <?php echo e($hero->hero_main_button_two); ?>

                                                      </a>
                                                  <?php endif; ?>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>

                  </div>
              </div>
          </div>
      </div>
  </section>
  <!-- End Hero Area -->
<?php /**PATH D:\Web App\X speed\resources\views/pages/front/sections/Hero/Slider.blade.php ENDPATH**/ ?>