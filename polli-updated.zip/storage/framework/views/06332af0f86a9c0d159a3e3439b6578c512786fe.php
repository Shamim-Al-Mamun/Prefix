    <!-- Paybill Area -->
    <section class="isp-standard-v1-paybill" style="min-height: 800px">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="paybill-tab-area">
                        <div class="row">

                            <div class="col-12">
                                <div class="paybill-tab-menu">
                                    <div class="list-group" id="list-tab" role="tablist">

                                        <?php if(count($payBillOptions) > 0): ?>
                                            <?php $__currentLoopData = $payBillOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payBillCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a class="list-group-item  <?php echo e($payBillCategory->id == 1 ? 'active' : ''); ?>"
                                                    data-bs-toggle="list" href="#bill<?php echo e($payBillCategory->id); ?>"
                                                    role="tab"
                                                    aria-selected="true"><?php echo e($payBillCategory->option); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        <a class="list-group-item" data-bs-toggle="list" href="#bank" role="tab"
                                            aria-selected="false" tabindex="-1">Bank
                                        </a>

                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="paybill-tab-details">
                                    <div class="tab-content" id="nav-tabContent">

                                        <?php if(count($payBillOptions) > 0): ?>
                                            <?php $__currentLoopData = $payBillOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payBillSubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-pane fade  <?php echo e($payBillSubCategory->id == 1 ? 'active show' : ''); ?>"
                                                    id="bill<?php echo e($payBillSubCategory->id); ?>" role="tabpanel">
                                                    <div class="paybill-tab-single">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-12">
                                                                <div class="paybill-tab-single-details">
                                                                    <div class="tab-content" id="nav-tabContent">

                                                                        <?php if(count($payBillSubCategory->PayBillOptionSteps) > 0): ?>
                                                                            <?php $__currentLoopData = $payBillSubCategory->PayBillOptionSteps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payBillImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if(!empty($payBillImg->img)): ?>
                                                                                    <div class="tab-pane fade  <?php echo e($loop->index == 0 ? 'active show' : ''); ?>"
                                                                                        id="bill-img<?php echo e($payBillImg->id); ?>"
                                                                                        role="tabpanel">
                                                                                        <div
                                                                                            class="paybill-tab-single-screenshot">

                                                                                            <?php if(!empty($payBillImg->img)): ?>
                                                                                                <div
                                                                                                    class="paybill-tab-single-scrrensht-img">
                                                                                                    <img src="<?php echo e(url($payBillImg->img)); ?>"
                                                                                                        alt="#" />
                                                                                                </div>
                                                                                            <?php endif; ?>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-12">
                                                                <div class="paybill-tab-single-menu">
                                                                    <div class="list-group" id="list-tab"
                                                                        role="tablist">

                                                                        <?php if(count($payBillSubCategory->PayBillOptionSteps) > 0): ?>
                                                                            <?php $__currentLoopData = $payBillSubCategory->PayBillOptionSteps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payBillText): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if(!empty($payBillText->text)): ?>
                                                                                    <a class="list-group-item  <?php echo e($loop->index == 0 ? 'active' : ''); ?>"
                                                                                        data-bs-toggle="list"
                                                                                        href="#bill-img<?php echo e($payBillText->id); ?>"
                                                                                        role="tab"
                                                                                        aria-selected="true">
                                                                                        <div
                                                                                            class="paybill-tab-list-group-single">
                                                                                            <span
                                                                                                class="paybill-tab-single-num"><?php echo e($loop->index + 1); ?></span>
                                                                                            <h5
                                                                                                class="paybill-tab-list-group-title">
                                                                                                <?php echo e($payBillText->text); ?>

                                                                                            </h5>
                                                                                        </div>
                                                                                    </a>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        <div class="tab-pane fade" id="bank" role="tabpanel">
                                            <div class="row">
                                                <?php if(count($PayBillBank) > 0): ?>
                                                    <?php $__currentLoopData = $PayBillBank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-lg-4 col-md-6 col-12">
                                                            <div class="paybill-bank-card">
                                                                <div class="paybill-bank-card-top">

                                                                    <?php if(!empty($bank->img)): ?>
                                                                        <div class="paybill-bank-card-icon">
                                                                            <img src="<?php echo e(url($bank->img)); ?>"
                                                                                alt="#" />
                                                                        </div>
                                                                    <?php endif; ?>

                                                                    <div class="paybill-bank-card-content">
                                                                        <h5 class="p-bank-card-cont-title">
                                                                            <?php echo e($bank->title); ?>

                                                                        </h5>
                                                                        <p class="p-bank-card-cont-text">
                                                                            <?php echo e($bank->text); ?>

                                                                        </p>
                                                                    </div>
                                                                </div>
                                                                <ul class="p-bank-card-cont-list">
                                                                    <li><span>Account name:</span> <?php echo e($bank->text); ?>

                                                                    </li>
                                                                    <li>
                                                                        <span>Account no:</span>
                                                                        <?php echo e($bank->account_no); ?>

                                                                    </li>
                                                                    <li><span>Routing no:</span>
                                                                        <?php echo e($bank->routing_no); ?>

                                                                    </li>
                                                                    <li><span>Branch:</span> <?php echo e($bank->branch); ?></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Paybill Area -->
<?php /**PATH D:\Web App\X speed\resources\views/pages/front/sections/Bill/Pay.blade.php ENDPATH**/ ?>