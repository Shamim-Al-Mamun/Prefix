  <!-- Service Area -->
  <section class="ISPTemplateV1-service">
      <div class="container">
          <div class="row">

              <?php if(count($features) > 0): ?>
                  <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp" data-wow-delay="100ms"
                          data-wow-duration="1000ms">
                          <div class="service-card-single">
                              <div class="service-card-icon">
                                  <?php if(!empty($feature->feature_icon)): ?>
                                      <i class="fa-solid <?php echo e($feature->feature_icon); ?>" style='font-size:48px'></i>
                                  <?php endif; ?>
                              </div>
                              <div class="service-card-content">
                                  <?php if(!empty($feature->feature_title)): ?>
                                      <h4 class="service-card-cont-title"><?php echo e($feature->feature_title); ?></h4>
                                  <?php endif; ?>
                                  <?php if(!empty($feature->feature_text)): ?>
                                      <p class="service-card-cont-text">
                                          <?php echo e($feature->feature_text); ?>

                                      </p>
                                  <?php endif; ?>
                              </div>
                          </div>
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>

          </div>
      </div>
  </section>
  <!-- End Service Area -->
<?php /**PATH D:\Web App\X speed\resources\views/pages/front/sections/Hero/Service.blade.php ENDPATH**/ ?>