<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('pages.front.sections.Blogs.Blog.Breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('pages.front.sections.Blogs.Blog.Blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web App\ISP\Prefix\resources\views/pages/front/Blog.blade.php ENDPATH**/ ?>