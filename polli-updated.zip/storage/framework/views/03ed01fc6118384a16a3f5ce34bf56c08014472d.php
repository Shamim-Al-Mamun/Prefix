<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h4 class="page-title">Settings</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="/dashboard">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.seo')); ?>">Site Settings</a>
            </li>
        </ul>
    </div>


    <div class="card">
        <form action="<?php echo e(route('admin.seo.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title">Meta tag</h4>
                <button class="btn btn-success" type="submit" name="submit">Save Header</button>
            </div>
            <div class="card-body">

                




                <div class="tab-content mt-2 mb-3" id="pills-with-icon-tabContent">

                    <div class="tab-pane fade show active" id="pills-home-icon" role="tabpanel"
                        aria-labelledby="pills-home-tab-icon">
                        
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="meta_name">Meta Name</label>
                                    <input type="text" class="form-control" id="meta_name" name="meta_name"
                                        placeholder="Type here" required value="<?php echo e($seo_settings->meta_name); ?>">
                                    <small id="emailHelp" class="form-text text-muted">Type meta name</small>
                                </div>
                                <div class="form-group">
                                    <label for="meta_description">Meta description</label>
                                    <textarea type="text" class="form-control" id="meta_description" name="meta_description" placeholder="Type here"
                                        required><?php echo e($seo_settings->meta_description); ?></textarea>
                                    <small id="emailHelp" class="form-text text-muted">Type meta description</small>
                                </div>
                                <div class="form-group">
                                    <label for="meta_keywords">Meta keywords</label>
                                    <input type="text" class="form-control" id="meta_keywords" name="meta_keywords"
                                        placeholder="Type here" required value="<?php echo e($seo_settings->meta_keywords); ?>">
                                    <small id="emailHelp" class="form-text text-muted">Type meta keywords</small>
                                </div>
                                <div class="form-group">
                                    <label for="meta_author">Auhtor Name</label>
                                    <input type="text" class="form-control" id="meta_author" name="meta_author"
                                        placeholder="Type here" required value="<?php echo e($seo_settings->meta_author); ?>">
                                    <small id="emailHelp" class="form-text text-muted">Type meta author</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    


                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web App\ISP\Prefix\resources\views/pages/dashboard/seo.blade.php ENDPATH**/ ?>