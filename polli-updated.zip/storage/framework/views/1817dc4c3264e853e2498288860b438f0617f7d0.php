



<div class="ISPTemplateV1-topbar">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-7 col-12">
                <div class="ISPTemplateV1-topbar-contact">
                    <ul class="ISPTemplateV1-topbar-contact-list">
                        <li>
                            <a href="tel:+880 1234 567890"><i class="fi-sr-phone-call"></i>880 1234 567890</a>
                        </li>
                        <li>
                            <a href="mailto:info@xplorenet.com.bd"><i
                                    class="fi fi-sr-envelope"></i>info@xplorenet.com.bd</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6 col-md-5 col-12">
                <div class="ISPTemplateV1-topbar-selfcare-links">
                    <ul class="ISPTemplateV1-topbar-selfcare-links-list">
                        <li>
                            <a href="#" target="_blank">Mobile app</a>
                        </li>
                        <li>
                            <a href="#" target="_blank">BTRC Tarrif</a>
                        </li>
                        <li>
                            <a href="#" target="_blank">Pay bill</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- Mobile Menu Modal -->
<div class="modal mobile-menu-modal offcanvas-modal fade" id="offcanvas-modal">
    <div class="modal-dialog offcanvas-dialog">
        <div class="modal-content">
            <div class="modal-header offcanvas-header">
                <!-- offcanvas-logo-start -->
                <div class="offcanvas-logo">
                    <?php if(!empty($header_settings->header_logo)): ?>
                        <a href="/">
                            <img src="<?php echo e(url($header_settings->header_logo)); ?>" alt="#" />
                        </a>
                    <?php endif; ?>
                </div>
                <!-- offcanvas-logo-end -->
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="icofont-close-line"></i>
                </button>
            </div>
            <div class="mobile-menu-modal-main-body">
                <!-- offcanvas-menu start -->
                <nav id="offcanvas-menu" class="offcanvas-menu">
                    <ul id="mobile-nav" class="list-none offcanvas-men-list">

                        <li class="link">
                            <a href="/">Home</a>
                        </li>

                        <li class="link">
                            <a href="/aboutus">About us</a>
                        </li>

                        

                        <li class="link">
                            <a href="/pricing">Pricing</a>
                        </li>

                        <li class="link">
                            <a href="/paybill">Pay bill</a>
                        </li>

                        <li class="link">
                            <a href="/coverage">Coverage</a>
                        </li>

                        <li class="link">
                            <a href="/contactus">Contact</a>
                        </li>

                        <li class="header-more-menu">
                            <div class="dropdown">
                                <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    More<i class="fi-rr-angle-small-down"></i>
                                </button>
                                <ul class="dropdown-menu">

                                    <li class="link">
                                        <a class="dropdown-item" href="/blog">Blog & offer</a>
                                    </li>

                                    <li class="link">
                                        <a class="dropdown-item" href="/speed">Speed test</a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                    </ul>
                    <div class="offcanvas-btn">
                        
                        <a href="#" class="ISPTemplateV1-btn">Self care</a>
                    </div>
                </nav>
                <!-- offcanvas-menu end -->
            </div>
        </div>
    </div>
</div>
<!-- End Mobile Menu Modal -->

<!-- Header Area -->
<header id="active-sticky" class="ISPTemplateV1-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-3 col-xl-2 col-md-3 col-12">
                <div class="header-logo">

                    <?php if(!empty($header_settings->header_logo)): ?>
                        <a href="/">
                            <img src="<?php echo e(url($header_settings->header_logo)); ?>" alt="#" />
                        </a>
                    <?php endif; ?>

                </div>
            </div>
            <div class="col-lg-10 col-md-10 col-12">
                <div class="header-menu-right">

                    <ul class="header-menu-list">

                        <li class="link">
                            <a href="/">Home</a>
                        </li>

                        <li class="link">
                            <a href="/aboutus">About us</a>
                        </li>

                        

                        <li class="link">
                            <a href="/pricing">Pricing</a>
                        </li>

                        <li class="link">
                            <a href="/paybill">Pay bill</a>
                        </li>

                        <li class="link">
                            <a href="/coverage">Coverage</a>
                        </li>

                        <li class="link">
                            <a href="/contactus">Contact</a>
                        </li>

                        <li class="header-more-menu">
                            <div class="dropdown">
                                <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    More<i class="fi-rr-angle-small-down"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    <li class="link">
                                        <a class="dropdown-item" href="/blogs">Blog & offer</a>
                                    </li>
                                    <li class="link">
                                        <a class="dropdown-item" href="/speed">Speed test</a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                    </ul>
                    <div class="header-menu-btn">
                        
                        <a href="#" class="ISPTemplateV1-btn">Self care</a>
                    </div>
                </div>
            </div>
            <div class="col-auto">
                <button type="button" class="mobile-menu-offcanvas-toggler" data-bs-toggle="modal"
                    data-bs-target="#offcanvas-modal">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </button>
            </div>
        </div>
    </div>
</header>
<!-- End Header Area -->

<script>
    const currentLocation = window.location.pathname;
    const menuItems = document.querySelectorAll('.link');

    menuItems.forEach(item => {
        const anchor = item.querySelector("a")
        const href = (anchor.getAttribute("href"))
        if (href === currentLocation) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // if (window.innerWidth < 600) {
    //     document.getElementById("myElement").style.display = "none";
    // }
</script>
<?php /**PATH D:\Web App\X speed\pollimulti\resources\views/layouts/front/header.blade.php ENDPATH**/ ?>