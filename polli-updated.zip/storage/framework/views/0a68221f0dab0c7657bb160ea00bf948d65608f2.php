
<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h4 class="page-title">Media</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.media.all')); ?>">Media</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.media.addnew')); ?>">Add New Media</a>
            </li>
        </ul>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">Create New Media</div>
        </div>
        <form action="<?php echo e(route('admin.media.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body">
               <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="medialist_title">Media Title</label>
                            <input type="text" class="form-control" id="medialist_title" name="medialist_title" placeholder="Type here">
                        </div>
                        <div class="form-group">
                            <label for="medialist_link">Medaia Link</label>
                            <input type="text" class="form-control" id="medialist_link" name="medialist_link" placeholder="Type Media Link">
                        </div>
                        <!-- <div class="form-group">
                            <select name="medialist_id">
                                <?php $__currentLoopData = $media_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($media_cat->id); ?>"><?php echo e($media_cat->medialist_category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div> -->
                        <div class="form-group">
                            <select class="form-control show-tick" name="media_category_id">
                                <option selected disabled>-- Please select--</option>
                                <?php $__currentLoopData = $media_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($media_cat->id); ?>"> <?php echo e($media_cat->medialist_category_name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="medialist_thumbnail mb-4">
                                <h4 class="hero_thumbnail-title">Set Thumbnail image</h4>
                                <input name="medialist_thumbnail" type="file" value="1"  class="imagecheck-input">
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-action">
                <button class="btn btn-success" type="submit" name="submit">Save Media</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
                


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web App\X speed\resources\views/pages/dashboard/media/addnew.blade.php ENDPATH**/ ?>